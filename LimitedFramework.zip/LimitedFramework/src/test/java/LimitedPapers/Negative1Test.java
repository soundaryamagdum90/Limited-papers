package LimitedPapers;

import java.io.IOException;
import java.time.Duration;

import org.limitedpapers.generic.fileutilities.PropertiesUtilities;
import org.limitedpapers.objectrepository.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Negative1Test {
	
	@Test
	public void negativeTest() throws IOException, InterruptedException {
//	public void invalidLoginTest()  {

		PropertiesUtilities propertyutility = new PropertiesUtilities();
		String BROWSER = propertyutility.readTheDataFromPropertiesFile("browser");
		String URL = propertyutility.readTheDataFromPropertiesFile("url");

		// ❗ Intentionally WRONG credentials for negative test
		String WRONG_EMAIL = "invalid@test.com";
		String WRONG_PASSWORD = "wrong12345";

		WebDriver driver = null;

		if (BROWSER.equals("chrome")) {
			driver = new ChromeDriver();

		} else if (BROWSER.equals("edge")) {
			driver = new EdgeDriver();

		} else if (BROWSER.equals("firefox")) {
			driver = new FirefoxDriver();
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get(URL);

		// ------------------ LOGIN ATTEMPT ----------------------

        LoginPage lp = new LoginPage(driver);
		lp.getLoginButton().click();
		lp.getUsernameTextField().sendKeys(WRONG_EMAIL);
		lp.getPasswordTextField().sendKeys(WRONG_PASSWORD);
		lp.getSubmitButton().click();

		

		// ------------------ VALIDATION --------------------------
		// Negative: After invalid login, logout button must NOT be displayed

		boolean isLoginFailed = false;

		try {
			// agar logout button mil gaya, login success hua (FAIL)
			driver.findElement(By.xpath("//a[contains(text(),'Logout')]"));
			isLoginFailed = false;
		} catch (Exception e) {
			// logout button nahi mila = expected = FAIL login = PASS test
			isLoginFailed = true;
		}

		Assert.assertTrue(isLoginFailed, "Login should fail with wrong credentials!");

		System.out.println("Negative test passed — Invalid login did NOT allow access.");
		Thread.sleep(2000);

		driver.quit();
	}
}



