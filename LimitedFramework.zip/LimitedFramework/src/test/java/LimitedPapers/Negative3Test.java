package LimitedPapers;

import java.io.IOException;
import java.time.Duration;

import org.limitedpapers.generic.fileutilities.PropertiesUtilities;
import org.limitedpapers.objectrepository.HomePage;
import org.limitedpapers.objectrepository.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Negative3Test {
	

//	public class NegativeSearchTest {
		
		@Test
		public void negative3Test() throws InterruptedException, IOException {
				
	//	public void invalidSearchTest() throws IOException, InterruptedException {

			PropertiesUtilities propertyutility = new PropertiesUtilities();
			String BROWSER = propertyutility.readTheDataFromPropertiesFile("browser");
			String URL = propertyutility.readTheDataFromPropertiesFile("url");
			String EMAIL = propertyutility.readTheDataFromPropertiesFile("username");
			String PASSWORD = propertyutility.readTheDataFromPropertiesFile("password");

			WebDriver driver = null;

			if (BROWSER.equals("chrome")) {
				driver = new ChromeDriver();

			} else if (BROWSER.equals("edge")) {
				driver = new EdgeDriver();

			} else if (BROWSER.equals("firefox")) {
				driver = new FirefoxDriver();
			}

			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			driver.get(URL);

			// ---------------- LOGIN -----------------------
			LoginPage lp = new LoginPage(driver);
			lp.getLoginButton().click();
			lp.getUsernameTextField().sendKeys(EMAIL);
			lp.getPasswordTextField().sendKeys(PASSWORD);
			lp.getSubmitButton().click();
			Thread.sleep(2000);

			// ---------------- NEGATIVE SEARCH -----------------------
			HomePage hp = new HomePage(driver);

			// Wrong search keyword  
			String wrongSearchText = "xyzinvalid12345";

			hp.getSearchBox().sendKeys(wrongSearchText);
			hp.getSearchButton().click();
			Thread.sleep(2000);

			// Verify error message (change locator as per your app)
			By noResults = By.xpath("//div[contains(text(),'No results')]");
			
		//	By noResults = By.partialLinkText("We're sorry, we found 0 matches on LimitedPapers.com for \"xyzinvalid12345\".");

			boolean isNoResultDisplayed = false;

			try {
				driver.findElement(noResults);
				isNoResultDisplayed = true;
			} catch (Exception e) {
				isNoResultDisplayed = false;
			}

			Assert.assertTrue(isNoResultDisplayed, "Search should fail for invalid product name!");

			System.out.println("Negative Test Passed — Invalid product search shows 'No results found'.");

			// ---------------- LOGOUT -----------------------
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", lp.getLoginButton());

			lp.getLogoutButton().click();

			Thread.sleep(3000);
			driver.quit();
		}
	}

