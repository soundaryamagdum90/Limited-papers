package LimitedPapers;

import java.io.IOException;
import java.time.Duration;

import org.limitedpapers.generic.fileutilities.PropertiesUtilities;
import org.limitedpapers.objectrepository.AddToCartPage;
import org.limitedpapers.objectrepository.EnvelopPage;
import org.limitedpapers.objectrepository.HomePage;
import org.limitedpapers.objectrepository.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class CreateEnvelopModuleTest {

	@Test
	
	public void createEnvelopModuleTest() throws InterruptedException, IOException {

		// Load properties
		PropertiesUtilities propetyutility = new PropertiesUtilities();
		String BROWSER = propetyutility.readTheDataFromPropertiesFile("browser");
		String URL = propetyutility.readTheDataFromPropertiesFile("url");
		String EMAIL = propetyutility.readTheDataFromPropertiesFile("username");
		String PASSWORD = propetyutility.readTheDataFromPropertiesFile("password");


		WebDriver driver = null;
		if (BROWSER.equals("chrome")) {
			driver = new ChromeDriver();

		} else if (BROWSER.equals("edge")) {
			driver = new EdgeDriver();

		} else if (BROWSER.equals("firefox")) {
			driver = new FirefoxDriver();
		}                 

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get(URL);

		

		// Login Using POM
		LoginPage lp = new LoginPage(driver);
		lp.getLoginButton().click();
		lp.getUsernameTextField().sendKeys(EMAIL);
		lp.getPasswordTextField().sendKeys(PASSWORD);
		lp.getSubmitButton().click();
		
		
		HomePage hp= new HomePage(driver);
		hp.getClickOnEnvelopsLink().click();
		
		EnvelopPage en=new EnvelopPage(driver);
		en.getBlackCategory().click();
		en.getProductItem().click();
		
		AddToCartPage ac=new AddToCartPage(driver);
		 ac.getAddToCartButton().click();
		 
		 
		 lp.getLoginButton().click();
		 lp.getLogoutButton().click();
		 
		 driver.quit();
		 
		


	
}
}
