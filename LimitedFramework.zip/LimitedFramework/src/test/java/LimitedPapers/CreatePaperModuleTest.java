package LimitedPapers;

import java.io.IOException;
import java.time.Duration;

import org.limitedpapers.generic.fileutilities.PropertiesUtilities;
import org.limitedpapers.objectrepository.AddToCartPage;
import org.limitedpapers.objectrepository.HomePage;
import org.limitedpapers.objectrepository.LoginPage;
import org.limitedpapers.objectrepository.PaperPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class CreatePaperModuleTest {

	@Test
	public void createpaperModuleTest()  throws IOException, InterruptedException {
		PropertiesUtilities propetyutility = new PropertiesUtilities();
		String BROWSER = propetyutility.readTheDataFromPropertiesFile("browser");
		String URL = propetyutility.readTheDataFromPropertiesFile("url");
		String EMAIL = propetyutility.readTheDataFromPropertiesFile("username");
		String PASSWORD = propetyutility.readTheDataFromPropertiesFile("password");

		WebDriver driver = null;
		if (BROWSER.equals("chrome")) {
			driver = new ChromeDriver();

		} else if (BROWSER.equals("edge")) {
			driver = new EdgeDriver();

		} else if (BROWSER.equals("firefox")) {
			driver = new FirefoxDriver();
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get(URL);

		LoginPage lp = new LoginPage(driver);
		lp.getLoginButton().click();
		lp.getUsernameTextField().sendKeys(EMAIL);
		lp.getPasswordTextField().sendKeys(PASSWORD);
		lp.getSubmitButton().click();
		Thread.sleep(2000);
		
		HomePage hp= new HomePage(driver);
		hp.getClickOnPaperLink().click();
		
		 PaperPage pg= new PaperPage(driver);
		 pg.getClickOnProduct().click();Thread.sleep(3000);
		 
		 AddToCartPage ac=new AddToCartPage(driver);
		 ac.getAddToCartButton().click();
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//img[@src='/images/exclose2.gif']")).click();
		 
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("arguments[0].click();", lp.getLoginButton());
		 //driver.findElement(By.xpath("//img[@src='/images/exclose2.gif']")).click();
		 
		 lp.getLogoutButton().click();
		 
		 driver.quit();
	}
}
		 
		
		
				