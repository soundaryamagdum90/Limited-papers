package LimitedPapers;

import java.time.Duration;

import org.limitedpapers.generic.fileutilities.PropertiesUtilities;
import org.limitedpapers.objectrepository.AddToCartPage;
import org.limitedpapers.objectrepository.HomePage;
import org.limitedpapers.objectrepository.LoginPage;
import org.limitedpapers.objectrepository.PaperPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

public class Negative4Test {
	

//	public class OutOfStockNegativeTest {
public void negative4Test() {
		
	//	public void addOutOfStockProductTest() throws IOException, InterruptedException {

			PropertiesUtilities properties = new PropertiesUtilities();
			String BROWSER = properties.readTheDataFromPropertiesFile("browser");
			String URL = properties.readTheDataFromPropertiesFile("url");
			String EMAIL = properties.readTheDataFromPropertiesFile("username");
			String PASSWORD = properties.readTheDataFromPropertiesFile("password");

			WebDriver driver = null;

			if (BROWSER.equals("chrome")) {
				driver = new ChromeDriver();
			} else if (BROWSER.equals("edge")) {
				driver = new EdgeDriver();
			} else if (BROWSER.equals("firefox")) {
				driver = new FirefoxDriver();
			}

			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			driver.get(URL);

			// LOGIN
			LoginPage lp = new LoginPage(driver);
			lp.getLoginButton().click();
			lp.getUsernameTextField().sendKeys(EMAIL);
			lp.getPasswordTextField().sendKeys(PASSWORD);
			lp.getSubmitButton().click();
			Thread.sleep(2000);

			// OPEN PAPER MODULE
			HomePage hp = new HomePage(driver);
			hp.getClickOnPaperLink().click();

			// OPEN OUT-OF-STOCK PRODUCT
			PaperPage pp = new PaperPage(driver);
			pp.getOutOfStockProduct().click();   // <-- OUT-OF-STOCK PRODUCT
			Thread.sleep(2000);

			// TRY TO ADD TO CART
			AddToCartPage ac = new AddToCartPage(driver);
			ac.getAddToCartButton().click();
			Thread.sleep(1000);

			// VALIDATION MESSAGE
			String actual = ac.getOutOfStockMessage().getText();
			String expected = "This product is currently out of stock";

			Assert.assertEquals(actual, expected, 
					"System allowed adding an out-of-stock product! This is incorrect behaviour.");

			// LOGOUT
			lp.getLogoutButton().click();
			driver.quit();
		}
	}
