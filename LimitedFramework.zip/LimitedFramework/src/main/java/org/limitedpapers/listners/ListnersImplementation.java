package org.limitedpapers.listners;

import java.io.ObjectInputFilter.Status;
import java.util.Date;

import org.limitedpapers.baseclass.BaseClass;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

public class ListnersImplementation implements ISuiteListener,ITestListener {
// 	public class ListenersImpplementation implements ISuiteListener,ITestListener {

		ExtentReports report;
		ExtentTest test;
	    
		
		@Override
		public void onTestStart(ITestResult result) {
			String testCase = result.getMethod().getMethodName();
			test = report.createTest(testCase);
			test.log(Status.INFO,""+testCase+"Execution Started");	
		}

		@Override
		public void onTestSuccess(ITestResult result) {
			String testCase = result.getMethod().getMethodName();
			test.log(Status.PASS,""+testCase+"Execution Pass" );
		}

		@Override
		public void onTestFailure(ITestResult result) {
			
		    String testCase = result.getMethod().getMethodName();
			test.log(Status.FAIL, ""+testCase+"Execution Failed");
			TakesScreenshot ts=(TakesScreenshot)BaseClass.sdriver;
			String src = ts.getScreenshotAs(OutputType.BASE64);
			test.addScreenCaptureFromBase64String(src);
			
			/*Date d=new Date();
			String date=d.toString().replaceAll("", "").replaceAll(":", "");
			File dest = new File("./screenshot/"+testCase+"error"+date+".png");
			
			try {
				FileHandler.copy(src, dest);
			} catch (IOException e) {
				e.printStackTrace();
			}*/
		}

		@Override
		public void onTestSkipped(ITestResult result) {
			String testCase = result.getMethod().getMethodName();
			test.log(Status.SKIP, ""+testCase+"Execution Skipped");
		}

		@Override
		public void onStart(ISuite suite) {
			
			Reporter.log("Report Configuration",true);
			Date d=new Date();
			String date=d.toString().replaceAll("", "").replaceAll(":", "");
			ExtentSparkReporter spar=new ExtentSparkReporter("./AdvancedReport/"+date+"ExecutionReport.html");
			spar.config().setDocumentTitle("Walkmate");
			spar.config().setReportName("WalkmateReport");
			spar.config().setTheme(Theme.STANDARD);
			
			report=new ExtentReports();
			report.attachReporter(spar);
			report.setSystemInfo("System", "HP");
			report.setSystemInfo("OS", "Windows11");
			report.setSystemInfo("browser", "chrome");
		} 
		
		@Override
		public void onFinish(ISuite suite) {
			Reporter.log("Take the Backup",true);
			report.flush();
			
		}
}
