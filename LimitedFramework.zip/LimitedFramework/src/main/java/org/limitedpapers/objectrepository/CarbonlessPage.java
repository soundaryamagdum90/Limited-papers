package org.limitedpapers.objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CarbonlessPage {
	
		public CarbonlessPage(WebDriver driver) {
			PageFactory.initElements(driver, this);
		}

		@FindBy(id = "nagnav_05")
		private WebElement clickOnCarbonless;

		@FindBy(xpath="//span[text()='Sizes']")
		private WebElement sizesFilter;

		@FindBy(xpath = "//a[text()='Item # 5891 / 1897']")
		private WebElement clickOnAddProduct;

		public WebElement getClickOnCarbonless() {
			return clickOnCarbonless;
		}

		public WebElement getSizesFilter() {
			return sizesFilter;
		}

		public WebElement getClickOnAddProduct() {
			return clickOnAddProduct;
		}
		
		
		
		
//		@FindBy(xpath = "//button[contains(text(),'Add to Cart')]")
//		private WebElement addToCartButton;
//		
//		@FindBy(xpath = "//img[@src='images/cart_top_login.gif']")
//		private WebElement cartButton;

//		public WebElement getAddAnyCarbonlessProduct() {
//			return addAnyCarbonlessProduct;
//		}

//		public WebElement getAddToCartButton() {
//			return addToCartButton;
//		}
//
//		public WebElement getCartButton() {
//			return cartButton;
//		}


	}

