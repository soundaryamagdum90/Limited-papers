package org.limitedpapers.objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		}
	
	@FindBy(xpath = "//img[@src='images/cart_top_login.gif']")
	private WebElement loginButton;
	
	@FindBy(id="email")
	private WebElement usernameTextField;
	
	@FindBy(name="password")
	private WebElement passwordTextField;
	
	@FindBy(id="image1")
	private WebElement submitButton;
	
	@FindBy(linkText = "Logout")
	private WebElement logoutButton;
	

	public WebElement getLogoutButton() {
		return logoutButton;
	}


	public WebElement getLoginButton() {
		return loginButton;
		}
	

	public WebElement getUsernameTextField() {
		return usernameTextField;
	}

	public WebElement getPasswordTextField() {
		return passwordTextField;
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}
	
	
	
}
