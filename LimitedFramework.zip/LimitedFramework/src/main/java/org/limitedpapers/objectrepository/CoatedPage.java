package org.limitedpapers.objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CoatedPage {
	
			public CoatedPage(WebDriver driver) {
			PageFactory.initElements(driver, this);
		}

		@FindBy(xpath="//span[text()='Finishes']")
		private WebElement finishesFilter;
		
		@FindBy(xpath = "//a[text()='Dull']")
		private WebElement finishDull;
		
		@FindBy(xpath = "//a[text()='Item # 279654']")
		private WebElement clickOnProduct;

		public WebElement getFinishesFilter() {
			return finishesFilter;
		}

		public WebElement getFinishDull() {
			return finishDull;
		}

		public WebElement getClickOnProduct() {
			return clickOnProduct;
		}
}

		



	

