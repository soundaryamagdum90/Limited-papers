package org.limitedpapers.objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddToCartPage {
	public AddToCartPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@type='image']/parent::span")
	private WebElement addToCartButton;
	
	public WebElement getAddToCartButton() {
		return addToCartButton;
	}

	
}
