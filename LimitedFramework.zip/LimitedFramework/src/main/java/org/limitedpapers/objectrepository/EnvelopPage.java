package org.limitedpapers.objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EnvelopPage {
	

		public EnvelopPage(WebDriver driver) {
			PageFactory.initElements(driver, this);
		}

		@FindBy(id = "updt_nav_02")
		private WebElement envelopeModule;
		
		@FindBy(xpath = "//span[text()='Color']")
		private WebElement clickOnColor;

		public WebElement getClickOnColor() {
			return clickOnColor;
		}

		@FindBy(xpath = "//a[text()='Black']")
		private WebElement blackCategory;

		@FindBy(xpath = "//a[text()='Item # 0396800']")
		private WebElement productItem;


		public WebElement getEnvelopeModule() {
			return envelopeModule;
		}

		public WebElement getBlackCategory() {
			return blackCategory;
		}

		public WebElement getProductItem() {
			return productItem;
		}

}

