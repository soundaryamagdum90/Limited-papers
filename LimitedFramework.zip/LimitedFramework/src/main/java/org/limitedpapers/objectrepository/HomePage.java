package org.limitedpapers.objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	public HomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		}
	@FindBy(id="updt_nav_01")
	private WebElement clickOnPaperLink;
	
	@FindBy(id="updt_nav_02")
	private WebElement clickOnEnvelopsLink;
	
	@FindBy(id="updt_nav_03")
	private WebElement clickOnCoverstockLink;
	
	@FindBy(id="updt_nav_04")
	private WebElement clickOnCoatedLink;
	
	@FindBy(id="updt_nav_05")
	private WebElement clickOnCarbonlessLink;
	
	@FindBy(xpath = "//a[text()='Black']")
	private WebElement clickOnBlackColor;
	
	@FindBy(xpath = "//span[text()='Weights']")
	private WebElement clickOnWeights;
	
	@FindBy(xpath = "//span[text()='Finishes']")
	private WebElement clickOnFinishes;
	
	@FindBy(xpath = "//span[text()='Sizes']")
	private WebElement clickOnSizes;
	
	@FindBy(id = "inp_searchbox")
	private WebElement searchBox;
	
	@FindBy(xpath = "//input[@type='submit']")
	private WebElement searchButton;
	
	
    public WebElement getSearchBox() {
		return searchBox;
	}

	public WebElement getSearchButton() {
		return searchButton;
	}

	//	@FindBy(xpath = "//img[@src='images/cart_top_login.gif']")
//	private WebElement loginButton;
//	
//	@FindBy(id="email")
//	private WebElement usernameTextField;
//	
//	@FindBy(name="password")
//	private WebElement passwordTextField;
//	
//	@FindBy(id="image1")
//	private WebElement submitButton;
//
	public WebElement getClickOnPaperLink() {
		return clickOnPaperLink;
	}

	public WebElement getClickOnEnvelopsLink() {
		return clickOnEnvelopsLink;
	}

	public WebElement getClickOnCoverstockLink() {
		return clickOnCoverstockLink;
	}

	public WebElement getClickOnCoatedLink() {
		return clickOnCoatedLink;
	}

	public WebElement getClickOnCarbonlessLink() {
		return clickOnCarbonlessLink;
	}

	public WebElement getClickOnBlackColor() {
		return clickOnBlackColor;
	}

	public WebElement getClickOnWeights() {
		return clickOnWeights;
	}

	public WebElement getClickOnFinishes() {
		return clickOnFinishes;
	}

	public WebElement getClickOnSizes() {
		return clickOnSizes;
	}
	
	

//	public WebElement getLoginButton() {
//		return loginButton;
//	}
//
//	public WebElement getUsernameTextField() {
//		return usernameTextField;
//	}
//
//	public WebElement getPasswordTextField() {
//		return passwordTextField;
//	}
//
//	public WebElement getSubmitButton() {
//		return submitButton;
//	}


	
	
}
