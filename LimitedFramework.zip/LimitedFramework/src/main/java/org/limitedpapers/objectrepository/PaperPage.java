package org.limitedpapers.objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaperPage {

	public PaperPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
   @FindBy(xpath = "//span[text()='Accent Opaque Warm White 60# Smooth 25\"x38\"']")
	private WebElement clickOnProduct;
   
   
    public WebElement getClickOnProduct() {
	return clickOnProduct;
}


	
	}

	

	
