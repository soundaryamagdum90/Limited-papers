package org.limitedpapers.objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CoverstockPage {

		public CoverstockPage(WebDriver driver) {
			PageFactory.initElements(driver, this);
		}

		@FindBy(id="nagnav_03")
		private WebElement clickOnCoverstock;
		
		@FindBy(xpath="//span[text()='Brands']")
		private WebElement clickOnBrands;

		@FindBy(id = "sidebrandstd_1")
		private WebElement brandsMenu;
		

		@FindBy(xpath = "//a[text()='Item # 188630I']")
		private WebElement clickOnProduct;
		

		public WebElement getClickOnCoverstock() {
			return clickOnCoverstock;
		}


		public WebElement getClickOnBrands() {
			return clickOnBrands;
		}


		public WebElement getBrandsMenu() {
			return brandsMenu;
		}


		public WebElement getClickOnProduct() {
			return clickOnProduct;
		}


}






	

