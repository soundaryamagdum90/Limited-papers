package org.limitedpapers.generic.webdriverutilities;

import java.time.Duration;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverUtilities {

	
//		public void waitForElement(WebDriver driver, WebElement element, int sec) {
//			WebDriverWait wait = new WebDriverWait(driver, java.time.Duration.ofSeconds(sec));
//			wait.until(ExpectedConditions.visibilityOf(element));
//		}
//		
	
	public WebElement FindAndClick(WebElement we, WebDriver driver) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

	    for (int i = 0; i < 3; i++) {
	        try {
	            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(we));
	            el.click();
	            return el;
	        } catch (StaleElementReferenceException e) {
	            System.out.println("Stale detected, retrying..." + (i+1));
	        }
	    }

	    throw new RuntimeException("Element remained stale after retries: " + we);
	}
	
	
		public void mousehoverAction(WebDriver driver, WebElement element) {
			Actions a = new Actions(driver);
			a.moveToElement(element).perform();
		}
	}
