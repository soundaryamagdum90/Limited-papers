package org.limitedpapers.baseclass;

import java.io.IOException;
import java.time.Duration;

import org.limitedpapers.generic.fileutilities.PropertiesUtilities;
import org.limitedpapers.objectrepository.HomePage;
import org.limitedpapers.objectrepository.LoginPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class BaseClass {

public  WebDriver driver;
	
	public static WebDriver sdriver;
	PropertiesUtilities propertyutility = new PropertiesUtilities();

	@BeforeSuite
	public void baseSuite() {
		Reporter.log("connect to DataBase", true);
	}

	@BeforeTest
	public void beforeTest() {
		Reporter.log("pre conditions", true);
	}


	@BeforeClass
	public void beforeClass() throws IOException  {
		String BROWSER = propertyutility.readTheDataFromPropertiesFile("browser");

		if (BROWSER.equals("chrome")) {
			driver = new ChromeDriver();
		} else if (BROWSER.equals("edge"))
			driver = new EdgeDriver();
		else if (BROWSER.equals("firefox"))
			driver = new FirefoxDriver();
		sdriver=driver;
	}

	@BeforeMethod
	public void beforeMethod() throws IOException {
		String URL = propertyutility.readTheDataFromPropertiesFile("url");
		String EMAIL = propertyutility.readTheDataFromPropertiesFile("username");
		String PASSWORD = propertyutility.readTheDataFromPropertiesFile("password");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get(URL);
		LoginPage lp = new LoginPage(driver);
		lp.getLoginButton().click();
		lp.getUsernameTextField().sendKeys(EMAIL);
		lp.getPasswordTextField().sendKeys(PASSWORD);
		lp.getSubmitButton().click();
	}

	@AfterMethod
	public void afterMethod() {
		
		LoginPage lp = new LoginPage(driver);
		lp.getLoginButton().click();
		lp.getLogoutButton().click();
	
	}

	@AfterClass
	public void afterClass() {
		driver.quit();
	}
}

